<!-- Fiszable -->

<p align="center"><b>Polskie szablony witryn <i>Facebook</i>, <i>PayPal</i> oraz <i>Instagram</i>.</b></p>

##

<h3><p align="center">Opis:</p></h3>

<b>Paczka zawiera trzy gotowe szablony w języku polskim.<br>
Należy skopiować pliki z wybranego folderu (<i>Facebook</i>, <i>Paypal</i> oraz <i>Instagram</i>)<br>
do głównego katalogu naszego serwera (np. <i>/var/www/html/</i> w przypadku <i>Apache2</i><br>
lub <i>.htdocs</i> w przypadku <i>XAMPP'a</i>).</b>
##

<details>
  <summary><h3>Zależności:</h3></summary>

<b>Fiszable</b> wymaga następujących skryptów w przypadku systemów typu <i>Linux</i>:<br>

- `php7.4`
- `libapache2-mod-php7.4`

<br>

W systemach <i>Windows</i> wymagany jest zainstalowany pakiet:<br>
- `XAMPP`
- `Wamp`

<center>Inspired by Creativity.<br>
  Created by <b>Remo Faller</b>.<br>
  <a href="https://sztuczka-magiczka.pl">Remo Faller/Sztuczka Magiczka</a><br>
  <b>2023</b></center>